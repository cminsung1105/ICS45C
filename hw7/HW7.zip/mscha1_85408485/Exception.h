#ifndef EXCEPTION_H
#define EXCEPTION_H

class IndexOutOfBoundsException {};

#endif
